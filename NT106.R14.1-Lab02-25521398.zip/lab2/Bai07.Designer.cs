﻿namespace lab2
{
    partial class Bai07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            treeView_explorer = new TreeView();
            groupBox_output = new GroupBox();
            pictureBox_output = new PictureBox();
            textBox_output = new TextBox();
            groupBox_output.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox_output).BeginInit();
            SuspendLayout();
            // 
            // treeView_explorer
            // 
            treeView_explorer.Location = new Point(12, 12);
            treeView_explorer.Name = "treeView_explorer";
            treeView_explorer.Size = new Size(234, 426);
            treeView_explorer.TabIndex = 0;
            treeView_explorer.AfterSelect += treeView_odia_AfterSelect;
            treeView_explorer.NodeMouseDoubleClick += treeView_explorer_NodeMouseDoubleClick;
            // 
            // groupBox_output
            // 
            groupBox_output.Controls.Add(pictureBox_output);
            groupBox_output.Controls.Add(textBox_output);
            groupBox_output.Location = new Point(269, 3);
            groupBox_output.Name = "groupBox_output";
            groupBox_output.Size = new Size(498, 435);
            groupBox_output.TabIndex = 1;
            groupBox_output.TabStop = false;
            groupBox_output.Text = "File Content";
            // 
            // pictureBox_output
            // 
            pictureBox_output.Location = new Point(6, 26);
            pictureBox_output.Name = "pictureBox_output";
            pictureBox_output.Size = new Size(486, 409);
            pictureBox_output.TabIndex = 1;
            pictureBox_output.TabStop = false;
            pictureBox_output.Click += pictureBox1_Click;
            // 
            // textBox_output
            // 
            textBox_output.Location = new Point(6, 26);
            textBox_output.Multiline = true;
            textBox_output.Name = "textBox_output";
            textBox_output.Size = new Size(486, 403);
            textBox_output.TabIndex = 0;
            // 
            // Bai07
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox_output);
            Controls.Add(treeView_explorer);
            Name = "Bai07";
            Text = "Bai07";
            MouseDoubleClick += Bai07_MouseDoubleClick;
            groupBox_output.ResumeLayout(false);
            groupBox_output.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox_output).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TreeView treeView_explorer;
        private GroupBox groupBox_output;
        private TextBox textBox_output;
        private PictureBox pictureBox_output;
    }
}