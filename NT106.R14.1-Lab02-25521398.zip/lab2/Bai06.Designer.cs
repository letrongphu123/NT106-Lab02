﻿namespace lab2
{
    partial class Bai06
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btn_addnguoidung = new Button();
            txt_name = new TextBox();
            lbl_name = new Label();
            btn_upload = new Button();
            lbl_nguoidung = new Label();
            cob_role = new ComboBox();
            txt_output = new TextBox();
            lbl_role = new Label();
            label1 = new Label();
            txt_tenmonan = new TextBox();
            lbl_tenmonan = new Label();
            lbl_upload = new Label();
            btn_addmonan = new Button();
            lv_menu = new ListView();
            imageList1 = new ImageList(components);
            btn_timmonan = new Button();
            cob_ncc = new ComboBox();
            lbl_ncc = new Label();
            SuspendLayout();
            // 
            // btn_addnguoidung
            // 
            btn_addnguoidung.BackColor = SystemColors.ButtonFace;
            btn_addnguoidung.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_addnguoidung.Location = new Point(82, 263);
            btn_addnguoidung.Name = "btn_addnguoidung";
            btn_addnguoidung.Size = new Size(108, 33);
            btn_addnguoidung.TabIndex = 68;
            btn_addnguoidung.Text = "Add";
            btn_addnguoidung.UseVisualStyleBackColor = false;
            btn_addnguoidung.Click += btn_add_Click;
            // 
            // txt_name
            // 
            txt_name.Location = new Point(23, 76);
            txt_name.Multiline = true;
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(220, 47);
            txt_name.TabIndex = 61;
            txt_name.KeyPress += txt_name_KeyPress;
            // 
            // lbl_name
            // 
            lbl_name.AutoSize = true;
            lbl_name.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_name.ForeColor = SystemColors.Highlight;
            lbl_name.Location = new Point(255, 87);
            lbl_name.Name = "lbl_name";
            lbl_name.Size = new Size(61, 25);
            lbl_name.TabIndex = 54;
            lbl_name.Text = "Name";
            // 
            // btn_upload
            // 
            btn_upload.BackColor = SystemColors.ButtonFace;
            btn_upload.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_upload.Location = new Point(656, 191);
            btn_upload.Name = "btn_upload";
            btn_upload.Size = new Size(134, 47);
            btn_upload.TabIndex = 53;
            btn_upload.Text = "Upload ";
            btn_upload.UseVisualStyleBackColor = false;
            btn_upload.Click += btn_upload_Click;
            // 
            // lbl_nguoidung
            // 
            lbl_nguoidung.AutoSize = true;
            lbl_nguoidung.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_nguoidung.Location = new Point(61, 17);
            lbl_nguoidung.Name = "lbl_nguoidung";
            lbl_nguoidung.Size = new Size(177, 28);
            lbl_nguoidung.TabIndex = 69;
            lbl_nguoidung.Text = "Thêm người dùng";
            // 
            // cob_role
            // 
            cob_role.FormattingEnabled = true;
            cob_role.Items.AddRange(new object[] { "Admin", "User" });
            cob_role.Location = new Point(23, 156);
            cob_role.Name = "cob_role";
            cob_role.Size = new Size(215, 28);
            cob_role.TabIndex = 70;
            // 
            // txt_output
            // 
            txt_output.BackColor = SystemColors.ButtonHighlight;
            txt_output.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_output.ForeColor = SystemColors.HotTrack;
            txt_output.Location = new Point(334, 14);
            txt_output.Multiline = true;
            txt_output.Name = "txt_output";
            txt_output.ReadOnly = true;
            txt_output.Size = new Size(295, 289);
            txt_output.TabIndex = 71;
            // 
            // lbl_role
            // 
            lbl_role.AutoSize = true;
            lbl_role.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_role.ForeColor = SystemColors.Highlight;
            lbl_role.Location = new Point(267, 159);
            lbl_role.Name = "lbl_role";
            lbl_role.Size = new Size(49, 25);
            lbl_role.TabIndex = 72;
            lbl_role.Text = "Role";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(736, 17);
            label1.Name = "label1";
            label1.Size = new Size(140, 28);
            label1.TabIndex = 73;
            label1.Text = "Thêm món ăn";
            // 
            // txt_tenmonan
            // 
            txt_tenmonan.Location = new Point(656, 65);
            txt_tenmonan.Multiline = true;
            txt_tenmonan.Name = "txt_tenmonan";
            txt_tenmonan.Size = new Size(220, 47);
            txt_tenmonan.TabIndex = 75;
            txt_tenmonan.KeyPress += txt_tenmonan_KeyPress;
            // 
            // lbl_tenmonan
            // 
            lbl_tenmonan.AutoSize = true;
            lbl_tenmonan.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_tenmonan.ForeColor = SystemColors.Highlight;
            lbl_tenmonan.Location = new Point(888, 76);
            lbl_tenmonan.Name = "lbl_tenmonan";
            lbl_tenmonan.Size = new Size(61, 25);
            lbl_tenmonan.TabIndex = 74;
            lbl_tenmonan.Text = "Name";
            // 
            // lbl_upload
            // 
            lbl_upload.AutoSize = true;
            lbl_upload.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_upload.ForeColor = SystemColors.Highlight;
            lbl_upload.Location = new Point(821, 203);
            lbl_upload.Name = "lbl_upload";
            lbl_upload.Size = new Size(128, 25);
            lbl_upload.TabIndex = 76;
            lbl_upload.Text = "Image Upload";
            // 
            // btn_addmonan
            // 
            btn_addmonan.BackColor = SystemColors.ButtonFace;
            btn_addmonan.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_addmonan.Location = new Point(750, 263);
            btn_addmonan.Name = "btn_addmonan";
            btn_addmonan.Size = new Size(108, 33);
            btn_addmonan.TabIndex = 77;
            btn_addmonan.Text = "Add";
            btn_addmonan.UseVisualStyleBackColor = false;
            btn_addmonan.Click += btn_addmonan_Click;
            // 
            // lv_menu
            // 
            lv_menu.LargeImageList = imageList1;
            lv_menu.Location = new Point(334, 17);
            lv_menu.Name = "lv_menu";
            lv_menu.Size = new Size(295, 286);
            lv_menu.TabIndex = 78;
            lv_menu.UseCompatibleStateImageBehavior = false;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageSize = new Size(64, 64);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // btn_timmonan
            // 
            btn_timmonan.BackColor = SystemColors.ButtonFace;
            btn_timmonan.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_timmonan.Location = new Point(409, 331);
            btn_timmonan.Name = "btn_timmonan";
            btn_timmonan.Size = new Size(134, 47);
            btn_timmonan.TabIndex = 79;
            btn_timmonan.Text = "Tìm món ăn";
            btn_timmonan.UseVisualStyleBackColor = false;
            btn_timmonan.Click += btn_timmonan_Click;
            // 
            // cob_ncc
            // 
            cob_ncc.FormattingEnabled = true;
            cob_ncc.Location = new Point(656, 141);
            cob_ncc.Name = "cob_ncc";
            cob_ncc.Size = new Size(134, 28);
            cob_ncc.TabIndex = 80;
            // 
            // lbl_ncc
            // 
            lbl_ncc.AutoSize = true;
            lbl_ncc.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_ncc.ForeColor = SystemColors.Highlight;
            lbl_ncc.Location = new Point(808, 140);
            lbl_ncc.Name = "lbl_ncc";
            lbl_ncc.Size = new Size(143, 25);
            lbl_ncc.TabIndex = 81;
            lbl_ncc.Text = "Người cung cấp";
            // 
            // Bai06
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(963, 454);
            Controls.Add(lbl_ncc);
            Controls.Add(cob_ncc);
            Controls.Add(btn_timmonan);
            Controls.Add(lv_menu);
            Controls.Add(btn_addmonan);
            Controls.Add(lbl_upload);
            Controls.Add(txt_tenmonan);
            Controls.Add(lbl_tenmonan);
            Controls.Add(label1);
            Controls.Add(lbl_role);
            Controls.Add(txt_output);
            Controls.Add(cob_role);
            Controls.Add(lbl_nguoidung);
            Controls.Add(btn_addnguoidung);
            Controls.Add(txt_name);
            Controls.Add(lbl_name);
            Controls.Add(btn_upload);
            Name = "Bai06";
            Text = "Bai06";
            Load += Bai06_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_addnguoidung;
        private TextBox txt_name;
        private Label lbl_name;
        private Button btn_upload;
        private Label lbl_nguoidung;
        private ComboBox cob_role;
        private TextBox txt_output;
        private Label lbl_role;
        private Label label1;
        private TextBox txt_tenmonan;
        private Label lbl_tenmonan;
        private Label lbl_upload;
        private Button btn_addmonan;
        private ListView lv_menu;
        private ImageList imageList1;
        private Button btn_timmonan;
        private ComboBox cob_ncc;
        private Label lbl_ncc;
    }
}