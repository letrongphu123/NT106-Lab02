﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace lab2
{
    public partial class Bai05 : Form
    {
        //khai bao cua truc du lieu bang dictionary
        private Dictionary<string, Thongtinphim> phim;
        private Dictionary<int, HashSet<string>> ghedaban;

        // Mỗi phòng chiếu có tổng cộng 15 ghế (A1-5, B1-5, C1-5)
        private const int SEATS_PER_ROOM = 15;

        //lop luu thong tin phim
        public class Thongtinphim
        {
            public decimal giatieuchuan { get; set; }
            public List<int> phong { get; set; }
            public HashSet<string> SoldSeats { get; set; } = new HashSet<string>(); // Lưu mã vé đã bán dạng "Phòng-Ghế" (VD: "1-A1")
        }

        public class MovieStat
        {
            public string MovieName { get; set; }
            public int TicketsSold { get; set; }
            public int TicketsRemaining { get; set; }
            public double SellRatio { get; set; }
            public decimal Revenue { get; set; }
            public int Rank { get; set; }
        }
        public Bai05()
        {
            InitializeComponent();
            InitializeData();
            SetupUI();
            pgb_tientrinh.Visible = false;
        }

        private void InitializeData()
        {
            // 1. Khởi tạo thông tin phim và giá ve
            phim = new Dictionary<string, Thongtinphim>
            {
                { "Đào, phở và piano", new Thongtinphim { giatieuchuan = 45000, phong = new List<int> { 1, 2, 3 } } },
                { "Mai", new Thongtinphim { giatieuchuan = 100000, phong = new List<int> { 2, 3 } } },
                { "Gặp lại chị bầu", new Thongtinphim { giatieuchuan = 70000, phong = new List<int> { 1 } } },
                { "Tarot", new Thongtinphim { giatieuchuan = 90000, phong = new List<int> { 3 } } }
            };


            //khoi tao danh sach ghe da ban cho 3 phong chieu
            ghedaban = new Dictionary<int, HashSet<string>>
            {
                { 1, new HashSet<string>() },
                { 2, new HashSet<string>() },
                { 3, new HashSet<string>() }
            };
        }

        private void SetupUI()
        {
            // Đổ dữ liệu phim vào ComboBox
            cmb_tenphim.DataSource = new BindingSource(phim, null);
            cmb_tenphim.DisplayMember = "Key";
            cmb_tenphim.ValueMember = "Value";
            cmb_tenphim.SelectedIndexChanged += cmb_tenphim_SelectedIndexChanged;

            // Thêm danh sách toàn bộ chỗ ngồi (A1-5, B1-5, C1-5)
            string[] allSeats = {
                    "A1", "A2", "A3", "A4", "A5",
                    "B1", "B2", "B3", "B4", "B5",
                    "C1", "C2", "C3", "C4", "C5"
                };
            clb_ghengoi.Items.AddRange(allSeats);
        }

        private void clb_ghengoi_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmb_tenphim_SelectedIndexChanged(object sender, EventArgs e)
        {
            //khi doi phim thi cap nhat lai danh sach phong tuong ung
            if (cmb_tenphim.SelectedItem is KeyValuePair<string, Thongtinphim> selectedPhim)
            {
                cmb_phongchieu.DataSource = selectedPhim.Value.phong;
            }
        }

        private void btn_datve_Click(object sender, EventArgs e)
        {
            // Kiểm tra thông tin khách hàng
            string fullName = txt_name.Text.Trim();
            if (string.IsNullOrEmpty(fullName))
            {
                MessageBox.Show("Vui lòng nhập họ và tên khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_name.Focus();
                return;
            }

            if (cmb_tenphim.SelectedItem == null || cmb_phongchieu.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn phim và phòng chiếu hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tenphim = ((KeyValuePair<string, Thongtinphim>)cmb_tenphim.SelectedItem).Key;
            Thongtinphim thongtinphim = ((KeyValuePair<string, Thongtinphim>)cmb_tenphim.SelectedItem).Value;
            int phongduocchon = (int)cmb_phongchieu.SelectedItem;

            //lay thong tin ghe ngoi duoc chon
            var gheduocchon = clb_ghengoi.CheckedItems.Cast<string>().ToList();
            if (gheduocchon.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất một vé xem phim!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Ràng buộc: Không được chọn quá 2 vé trong 1 giao dịch
            if (gheduocchon.Count > 2)
            {
                MessageBox.Show("Mỗi lần đặt không được chọn nhiều hơn 2 vé!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kiểm tra ghế đã được mua trước đó chưa
            foreach (var ghe in gheduocchon)
            {
                if (ghedaban[phongduocchon].Contains(ghe))
                {
                    MessageBox.Show($"Ghế {ghe} ở phòng {phongduocchon} đã được người khác mua trước đó. Vui lòng chọn ghế khác!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Tính tiền vé
            decimal tongtienve = 0;
            foreach (var ghe in gheduocchon)
            {
                tongtienve += TinhTien(ghe, thongtinphim.giatieuchuan);
            }

            // Cập nhật trạng thái ghế đã bán
            foreach (var ghe in gheduocchon)
            {
                ghedaban[phongduocchon].Add(ghe);
            }

            // Xuất kết quả ra màn hình
            string result = $"=== THÔNG TIN VÉ XEM PHIM ===\r\n" +
                            $"- Họ và tên khách: {fullName}\r\n" +
                            $"- Tên phim: {tenphim}\r\n" +
                            $"- Phòng chiếu: Phòng {phongduocchon}\r\n" +
                            $"- Các vé đã chọn: {string.Join(", ", gheduocchon)}\r\n" +
                            $"- Tổng tiền thanh toán: {tongtienve:N0} VNĐ";

            txt_output.Text = result;
            UpdateSeatStatusAfterBooking(phongduocchon);
        }

        private void UpdateSeatStatusAfterBooking(int currentRoom)
        {
            for (int i = 0; i < clb_ghengoi.Items.Count; i++)
            {
                string seatName = clb_ghengoi.Items[i].ToString();

                // 1. Bỏ tích chọn (Uncheck) tất cả các ghế sau khi đặt xong
                clb_ghengoi.SetItemChecked(i, false);
            }
        }

        private decimal TinhTien(string ghe, decimal giatieuchuan)
        {
            // Vé vớt: A1, A5, C1, C5 -> 1/4 giá chuẩn
            if (ghe == "A1" || ghe == "A5" || ghe == "C1" || ghe == "C5")
            {
                return giatieuchuan * 0.25m;
            }
            // Vé VIP: B2, B3, B4 -> 2 lần giá chuẩn
            else if (ghe == "B2" || ghe == "B3" || ghe == "B4")
            {
                return giatieuchuan * 2.0m;
            }
            // Vé thường: Các ghế còn lại -> 1 lần giá chuẩn
            else
            {
                return giatieuchuan * 1.0m;
            }
        }

        private async void btn_docfile_Click(object sender, EventArgs e)
        {
            string filePath = "D:\\project_nt106\\lab2\\input5.txt";

            if (!File.Exists(filePath))
            {
                MessageBox.Show($"Không tìm thấy tệp {filePath}!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                btn_docfile.Enabled = false;
                phim.Clear();

                StringBuilder resultBuilder = new StringBuilder();
                resultBuilder.AppendLine("=== THÔNG TIN ĐỌC TỪ FILE INPUT5.TXT ===");

                using (StreamReader reader = new StreamReader(filePath, Encoding.UTF8))
                {
                    string line;
                    // Cấu trúc 3 dòng: <tên phim> -> <giá vé chuẩn> -> <phòng chiếu>
                    while ((line = await reader.ReadLineAsync()) != null)
                    {
                        string movieName = line.Trim();
                        if (string.IsNullOrEmpty(movieName)) continue;

                        string priceLine = await reader.ReadLineAsync();
                        string roomLine = await reader.ReadLineAsync();

                        if (priceLine == null || roomLine == null) break;

                        decimal standardPrice = decimal.Parse(priceLine.Trim());
                        List<int> rooms = roomLine.Split(',').Select(r => int.Parse(r.Trim())).ToList();

                        phim[movieName] = new Thongtinphim
                        {
                            giatieuchuan = standardPrice,
                            phong = rooms
                        };

                        resultBuilder.AppendLine($"- Phim: {movieName} | Giá chuẩn: {standardPrice:N0}đ | Phòng: {string.Join(", ", rooms)}");
                    }
                }

                cmb_tenphim.DataSource = new BindingSource(phim, null);
                cmb_tenphim.DisplayMember = "Key";
                cmb_tenphim.ValueMember = "Value";

                txt_output.Text = resultBuilder.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi định dạng file input5.txt: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btn_docfile.Enabled = true;
            }
        }

        private async void btn_ghifile_Click(object sender, EventArgs e)
        {
            if (phim.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu phim để thống kê!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btn_ghifile.Enabled = false;
            pgb_tientrinh.Visible = true;
            if (pgb_tientrinh != null)
            {
                pgb_tientrinh.Minimum = 0;
                pgb_tientrinh.Maximum = 100;
                pgb_tientrinh.Value = 0;
            }

            await Task.Run(async () =>
            {
                UpdateProgress(20);

                var statsList = new List<MovieStat>();

                foreach (var kvp in phim)
                {
                    string movieName = kvp.Key;
                    Thongtinphim info = kvp.Value;

                    int totalCapacity = info.phong.Count * SEATS_PER_ROOM;
                    int ticketsSold = info.SoldSeats.Count;
                    int ticketsRemaining = totalCapacity - ticketsSold;
                    double sellRatio = totalCapacity > 0 ? ((double)ticketsSold / totalCapacity) * 100 : 0;

                    decimal revenue = 0;
                    foreach (var seatCode in info.SoldSeats)
                    {
                        string seatName = seatCode.Split('-')[1];
                        revenue += TinhTien(seatName, info.giatieuchuan);
                    }

                    statsList.Add(new MovieStat
                    {
                        MovieName = movieName,
                        TicketsSold = ticketsSold,
                        TicketsRemaining = ticketsRemaining,
                        SellRatio = sellRatio,
                        Revenue = revenue
                    });
                }

                UpdateProgress(50);

                // Xếp hạng doanh thu từ cao đến thấp
                var rankedStats = statsList
                    .OrderByDescending(s => s.Revenue)
                    .ThenByDescending(s => s.TicketsSold)
                    .ToList();

                for (int i = 0; i < rankedStats.Count; i++)
                {
                    rankedStats[i].Rank = i + 1;
                }

                UpdateProgress(75);

                // Ghi file output5.txt 
                using (FileStream fs = new FileStream("D:\\project_nt106\\lab2\\output5.txt", FileMode.Create, FileAccess.Write))
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    await writer.WriteLineAsync("=================================================================================================");
                    await writer.WriteLineAsync("                                BÁO CÁO THỐNG KÊ DOANH THU PHÒNG VÉ                                ");
                    await writer.WriteLineAsync("=================================================================================================");
                    await writer.WriteLineAsync(string.Format("{0,-25} | {1,-10} | {2,-10} | {3,-12} | {4,-18} | {5,-8}",
                        "Tên phim", "Vé bán", "Vé tồn", "Tỉ lệ bán", "Doanh thu (VNĐ)", "Xếp hạng"));
                    await writer.WriteLineAsync("-------------------------------------------------------------------------------------------------");

                    foreach (var stat in rankedStats)
                    {
                        string line = string.Format("{0,-25} | {1,-10} | {2,-10} | {3,-10:F2}%  | {4,-18:N0} | #{5,-7}",
                            stat.MovieName,
                            stat.TicketsSold,
                            stat.TicketsRemaining,
                            stat.SellRatio,
                            stat.Revenue,
                            stat.Rank);
                        await writer.WriteLineAsync(line);
                    }
                    await writer.WriteLineAsync("=================================================================================================");
                }

                UpdateProgress(100);
            });

            MessageBox.Show("Xuất file 'output5.txt' thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_ghifile.Enabled = true;
            pgb_tientrinh.Visible = false;
        }

        private void UpdateProgress(int value)
        {
            if (pgb_tientrinh == null) return;
            if (pgb_tientrinh.InvokeRequired)
            {
                pgb_tientrinh.Invoke(new Action(() => pgb_tientrinh.Value = value));
            }
            else
            {
                pgb_tientrinh.Value = value;
            }
        }
    }
}

   
