﻿namespace lab2
{
    partial class Bai01
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_docfile = new Button();
            btn_ghifile = new Button();
            lbl_title = new Label();
            txt_output = new TextBox();
            SuspendLayout();
            // 
            // btn_docfile
            // 
            btn_docfile.BackColor = SystemColors.ActiveCaption;
            btn_docfile.Font = new Font("Segoe UI Semibold", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_docfile.Location = new Point(77, 107);
            btn_docfile.Name = "btn_docfile";
            btn_docfile.Size = new Size(211, 59);
            btn_docfile.TabIndex = 0;
            btn_docfile.Text = "ĐỌC FILE";
            btn_docfile.UseVisualStyleBackColor = false;
            btn_docfile.Click += btn_docfile_Click;
            // 
            // btn_ghifile
            // 
            btn_ghifile.BackColor = SystemColors.ActiveCaption;
            btn_ghifile.Font = new Font("Segoe UI Semibold", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_ghifile.Location = new Point(77, 215);
            btn_ghifile.Name = "btn_ghifile";
            btn_ghifile.Size = new Size(211, 59);
            btn_ghifile.TabIndex = 1;
            btn_ghifile.Text = "GHI FILE";
            btn_ghifile.UseVisualStyleBackColor = false;
            btn_ghifile.Click += btn_ghifile_Click;
            // 
            // lbl_title
            // 
            lbl_title.AutoSize = true;
            lbl_title.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_title.Location = new Point(261, 18);
            lbl_title.Name = "lbl_title";
            lbl_title.Size = new Size(289, 46);
            lbl_title.TabIndex = 2;
            lbl_title.Text = "GHI VÀ ĐỌC FILE";
            // 
            // txt_output
            // 
            txt_output.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_output.Location = new Point(361, 107);
            txt_output.Multiline = true;
            txt_output.Name = "txt_output";
            txt_output.ReadOnly = true;
            txt_output.ScrollBars = ScrollBars.Vertical;
            txt_output.Size = new Size(382, 316);
            txt_output.TabIndex = 3;
            // 
            // Bai01
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_output);
            Controls.Add(lbl_title);
            Controls.Add(btn_ghifile);
            Controls.Add(btn_docfile);
            Name = "Bai01";
            Text = "Bai01";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_docfile;
        private Button btn_ghifile;
        private Label lbl_title;
        private TextBox txt_output;
    }
}
