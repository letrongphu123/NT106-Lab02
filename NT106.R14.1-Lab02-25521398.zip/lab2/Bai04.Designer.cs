﻿namespace lab2
{
    partial class Bai04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_writefile = new Button();
            btnreadfile = new Button();
            txt_output = new TextBox();
            lbl_name = new Label();
            lblid = new Label();
            lblphone = new Label();
            lblcourse1 = new Label();
            lblcourse2 = new Label();
            lblcourse3 = new Label();
            lblaverage = new Label();
            txt_name = new TextBox();
            lbl_average2 = new Label();
            lbl_course3_2 = new Label();
            lbl_course2_2 = new Label();
            lbl_course1_2 = new Label();
            lbl_phone2 = new Label();
            lbl_id2 = new Label();
            lbl_name2 = new Label();
            txt_id = new TextBox();
            txt_phone = new TextBox();
            txt_course1 = new TextBox();
            txt_course2 = new TextBox();
            txt_course3 = new TextBox();
            txt_average = new TextBox();
            txt_average2 = new TextBox();
            txt_course3_2 = new TextBox();
            txt_course2_2 = new TextBox();
            txt_course1_2 = new TextBox();
            txt_phone2 = new TextBox();
            txt_id2 = new TextBox();
            txt_name2 = new TextBox();
            btn_add = new Button();
            btn_back = new Button();
            btn_next = new Button();
            label2 = new Label();
            lbl_page = new Label();
            SuspendLayout();
            // 
            // btn_writefile
            // 
            btn_writefile.BackColor = SystemColors.ButtonFace;
            btn_writefile.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_writefile.Location = new Point(12, 12);
            btn_writefile.Name = "btn_writefile";
            btn_writefile.Size = new Size(212, 43);
            btn_writefile.TabIndex = 1;
            btn_writefile.Text = "Write to a file";
            btn_writefile.UseVisualStyleBackColor = false;
            btn_writefile.Click += btn_writefile_Click;
            // 
            // btnreadfile
            // 
            btnreadfile.BackColor = SystemColors.ButtonFace;
            btnreadfile.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnreadfile.Location = new Point(576, 12);
            btnreadfile.Name = "btnreadfile";
            btnreadfile.Size = new Size(212, 43);
            btnreadfile.TabIndex = 2;
            btnreadfile.Text = "Button to read a file";
            btnreadfile.UseVisualStyleBackColor = false;
            btnreadfile.Click += btnreadfile_Click;
            // 
            // txt_output
            // 
            txt_output.BackColor = SystemColors.ButtonHighlight;
            txt_output.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_output.ForeColor = SystemColors.HotTrack;
            txt_output.Location = new Point(250, 12);
            txt_output.Multiline = true;
            txt_output.Name = "txt_output";
            txt_output.ReadOnly = true;
            txt_output.Size = new Size(295, 426);
            txt_output.TabIndex = 16;
            // 
            // lbl_name
            // 
            lbl_name.AutoSize = true;
            lbl_name.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_name.ForeColor = SystemColors.Highlight;
            lbl_name.Location = new Point(178, 71);
            lbl_name.Name = "lbl_name";
            lbl_name.Size = new Size(61, 25);
            lbl_name.TabIndex = 17;
            lbl_name.Text = "Name";
            // 
            // lblid
            // 
            lblid.AutoSize = true;
            lblid.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblid.ForeColor = SystemColors.Highlight;
            lblid.Location = new Point(209, 116);
            lblid.Name = "lblid";
            lblid.Size = new Size(30, 25);
            lblid.TabIndex = 18;
            lblid.Text = "ID";
            // 
            // lblphone
            // 
            lblphone.AutoSize = true;
            lblphone.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblphone.ForeColor = SystemColors.Highlight;
            lblphone.Location = new Point(174, 161);
            lblphone.Name = "lblphone";
            lblphone.Size = new Size(65, 25);
            lblphone.TabIndex = 19;
            lblphone.Text = "Phone";
            // 
            // lblcourse1
            // 
            lblcourse1.AutoSize = true;
            lblcourse1.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcourse1.ForeColor = SystemColors.Highlight;
            lblcourse1.Location = new Point(157, 207);
            lblcourse1.Name = "lblcourse1";
            lblcourse1.Size = new Size(82, 25);
            lblcourse1.TabIndex = 20;
            lblcourse1.Text = "Course 1";
            lblcourse1.Click += lblcourse1_Click;
            // 
            // lblcourse2
            // 
            lblcourse2.AutoSize = true;
            lblcourse2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcourse2.ForeColor = SystemColors.Highlight;
            lblcourse2.Location = new Point(154, 255);
            lblcourse2.Name = "lblcourse2";
            lblcourse2.Size = new Size(85, 25);
            lblcourse2.TabIndex = 21;
            lblcourse2.Text = "Course 2";
            // 
            // lblcourse3
            // 
            lblcourse3.AutoSize = true;
            lblcourse3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcourse3.ForeColor = SystemColors.Highlight;
            lblcourse3.Location = new Point(154, 301);
            lblcourse3.Name = "lblcourse3";
            lblcourse3.Size = new Size(85, 25);
            lblcourse3.TabIndex = 22;
            lblcourse3.Text = "Course 3";
            // 
            // lblaverage
            // 
            lblaverage.AutoSize = true;
            lblaverage.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblaverage.ForeColor = SystemColors.Highlight;
            lblaverage.Location = new Point(159, 346);
            lblaverage.Name = "lblaverage";
            lblaverage.Size = new Size(80, 25);
            lblaverage.TabIndex = 23;
            lblaverage.Text = "Average";
            // 
            // txt_name
            // 
            txt_name.Location = new Point(12, 71);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(133, 27);
            txt_name.TabIndex = 31;
            txt_name.KeyPress += txt_name_KeyPress;
            // 
            // lbl_average2
            // 
            lbl_average2.AutoSize = true;
            lbl_average2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_average2.ForeColor = SystemColors.Highlight;
            lbl_average2.Location = new Point(708, 346);
            lbl_average2.Name = "lbl_average2";
            lbl_average2.Size = new Size(80, 25);
            lbl_average2.TabIndex = 38;
            lbl_average2.Text = "Average";
            // 
            // lbl_course3_2
            // 
            lbl_course3_2.AutoSize = true;
            lbl_course3_2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_course3_2.ForeColor = SystemColors.Highlight;
            lbl_course3_2.Location = new Point(703, 301);
            lbl_course3_2.Name = "lbl_course3_2";
            lbl_course3_2.Size = new Size(85, 25);
            lbl_course3_2.TabIndex = 37;
            lbl_course3_2.Text = "Course 3";
            // 
            // lbl_course2_2
            // 
            lbl_course2_2.AutoSize = true;
            lbl_course2_2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_course2_2.ForeColor = SystemColors.Highlight;
            lbl_course2_2.Location = new Point(703, 255);
            lbl_course2_2.Name = "lbl_course2_2";
            lbl_course2_2.Size = new Size(85, 25);
            lbl_course2_2.TabIndex = 36;
            lbl_course2_2.Text = "Course 2";
            // 
            // lbl_course1_2
            // 
            lbl_course1_2.AutoSize = true;
            lbl_course1_2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_course1_2.ForeColor = SystemColors.Highlight;
            lbl_course1_2.Location = new Point(706, 207);
            lbl_course1_2.Name = "lbl_course1_2";
            lbl_course1_2.Size = new Size(82, 25);
            lbl_course1_2.TabIndex = 35;
            lbl_course1_2.Text = "Course 1";
            // 
            // lbl_phone2
            // 
            lbl_phone2.AutoSize = true;
            lbl_phone2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_phone2.ForeColor = SystemColors.Highlight;
            lbl_phone2.Location = new Point(723, 161);
            lbl_phone2.Name = "lbl_phone2";
            lbl_phone2.Size = new Size(65, 25);
            lbl_phone2.TabIndex = 34;
            lbl_phone2.Text = "Phone";
            // 
            // lbl_id2
            // 
            lbl_id2.AutoSize = true;
            lbl_id2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_id2.ForeColor = SystemColors.Highlight;
            lbl_id2.Location = new Point(758, 116);
            lbl_id2.Name = "lbl_id2";
            lbl_id2.Size = new Size(30, 25);
            lbl_id2.TabIndex = 33;
            lbl_id2.Text = "ID";
            // 
            // lbl_name2
            // 
            lbl_name2.AutoSize = true;
            lbl_name2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_name2.ForeColor = SystemColors.Highlight;
            lbl_name2.Location = new Point(727, 71);
            lbl_name2.Name = "lbl_name2";
            lbl_name2.Size = new Size(61, 25);
            lbl_name2.TabIndex = 32;
            lbl_name2.Text = "Name";
            // 
            // txt_id
            // 
            txt_id.Location = new Point(12, 117);
            txt_id.Name = "txt_id";
            txt_id.Size = new Size(133, 27);
            txt_id.TabIndex = 39;
            txt_id.KeyPress += txt_id_KeyPress;
            txt_id.Leave += txt_id_Leave;
            // 
            // txt_phone
            // 
            txt_phone.Location = new Point(12, 159);
            txt_phone.Name = "txt_phone";
            txt_phone.Size = new Size(133, 27);
            txt_phone.TabIndex = 40;
            txt_phone.KeyPress += txt_phone_KeyPress;
            txt_phone.Leave += txt_phone_Leave;
            // 
            // txt_course1
            // 
            txt_course1.Location = new Point(12, 205);
            txt_course1.Name = "txt_course1";
            txt_course1.Size = new Size(133, 27);
            txt_course1.TabIndex = 41;
            txt_course1.KeyPress += txt_course1_KeyPress;
            txt_course1.Leave += txt_course1_Leave;
            // 
            // txt_course2
            // 
            txt_course2.Location = new Point(12, 253);
            txt_course2.Name = "txt_course2";
            txt_course2.Size = new Size(133, 27);
            txt_course2.TabIndex = 42;
            txt_course2.KeyPress += txt_course2_KeyPress;
            txt_course2.Leave += txt_course2_Leave;
            // 
            // txt_course3
            // 
            txt_course3.Location = new Point(12, 299);
            txt_course3.Name = "txt_course3";
            txt_course3.Size = new Size(133, 27);
            txt_course3.TabIndex = 43;
            txt_course3.KeyPress += txt_course3_KeyPress;
            txt_course3.Leave += txt_course3_Leave;
            // 
            // txt_average
            // 
            txt_average.Location = new Point(12, 347);
            txt_average.Name = "txt_average";
            txt_average.ReadOnly = true;
            txt_average.Size = new Size(133, 27);
            txt_average.TabIndex = 44;
            // 
            // txt_average2
            // 
            txt_average2.Location = new Point(558, 347);
            txt_average2.Name = "txt_average2";
            txt_average2.ReadOnly = true;
            txt_average2.Size = new Size(133, 27);
            txt_average2.TabIndex = 51;
            // 
            // txt_course3_2
            // 
            txt_course3_2.Location = new Point(558, 299);
            txt_course3_2.Name = "txt_course3_2";
            txt_course3_2.ReadOnly = true;
            txt_course3_2.Size = new Size(133, 27);
            txt_course3_2.TabIndex = 50;
            // 
            // txt_course2_2
            // 
            txt_course2_2.Location = new Point(558, 253);
            txt_course2_2.Name = "txt_course2_2";
            txt_course2_2.ReadOnly = true;
            txt_course2_2.Size = new Size(133, 27);
            txt_course2_2.TabIndex = 49;
            // 
            // txt_course1_2
            // 
            txt_course1_2.Location = new Point(558, 205);
            txt_course1_2.Name = "txt_course1_2";
            txt_course1_2.ReadOnly = true;
            txt_course1_2.Size = new Size(133, 27);
            txt_course1_2.TabIndex = 48;
            // 
            // txt_phone2
            // 
            txt_phone2.Location = new Point(558, 159);
            txt_phone2.Name = "txt_phone2";
            txt_phone2.ReadOnly = true;
            txt_phone2.Size = new Size(133, 27);
            txt_phone2.TabIndex = 47;
            // 
            // txt_id2
            // 
            txt_id2.Location = new Point(558, 117);
            txt_id2.Name = "txt_id2";
            txt_id2.ReadOnly = true;
            txt_id2.Size = new Size(133, 27);
            txt_id2.TabIndex = 46;
            // 
            // txt_name2
            // 
            txt_name2.Location = new Point(558, 71);
            txt_name2.Name = "txt_name2";
            txt_name2.ReadOnly = true;
            txt_name2.Size = new Size(133, 27);
            txt_name2.TabIndex = 45;
            // 
            // btn_add
            // 
            btn_add.BackColor = SystemColors.ButtonFace;
            btn_add.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_add.Location = new Point(62, 396);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(108, 33);
            btn_add.TabIndex = 52;
            btn_add.Text = "Add";
            btn_add.UseVisualStyleBackColor = false;
            btn_add.Click += btn_add_Click;
            // 
            // btn_back
            // 
            btn_back.BackColor = SystemColors.ButtonFace;
            btn_back.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_back.Location = new Point(550, 396);
            btn_back.Name = "btn_back";
            btn_back.Size = new Size(84, 33);
            btn_back.TabIndex = 53;
            btn_back.Text = "Back";
            btn_back.UseVisualStyleBackColor = false;
            btn_back.Click += btn_back_Click;
            // 
            // btn_next
            // 
            btn_next.BackColor = SystemColors.ButtonFace;
            btn_next.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_next.Location = new Point(706, 396);
            btn_next.Name = "btn_next";
            btn_next.Size = new Size(85, 33);
            btn_next.TabIndex = 54;
            btn_next.Text = "Next";
            btn_next.UseVisualStyleBackColor = false;
            btn_next.Click += btn_next_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(662, 409);
            label2.Name = "label2";
            label2.Size = new Size(0, 20);
            label2.TabIndex = 56;
            // 
            // lbl_page
            // 
            lbl_page.AutoSize = true;
            lbl_page.Location = new Point(641, 403);
            lbl_page.Name = "lbl_page";
            lbl_page.Size = new Size(66, 20);
            lbl_page.TabIndex = 57;
            lbl_page.Text = "lbl_page";
            lbl_page.Click += lbl_page_Click;
            // 
            // Bai04
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lbl_page);
            Controls.Add(label2);
            Controls.Add(btn_next);
            Controls.Add(btn_back);
            Controls.Add(btn_add);
            Controls.Add(txt_average2);
            Controls.Add(txt_course3_2);
            Controls.Add(txt_course2_2);
            Controls.Add(txt_course1_2);
            Controls.Add(txt_phone2);
            Controls.Add(txt_id2);
            Controls.Add(txt_name2);
            Controls.Add(txt_average);
            Controls.Add(txt_course3);
            Controls.Add(txt_course2);
            Controls.Add(txt_course1);
            Controls.Add(txt_phone);
            Controls.Add(txt_id);
            Controls.Add(lbl_average2);
            Controls.Add(lbl_course3_2);
            Controls.Add(lbl_course2_2);
            Controls.Add(lbl_course1_2);
            Controls.Add(lbl_phone2);
            Controls.Add(lbl_id2);
            Controls.Add(lbl_name2);
            Controls.Add(txt_name);
            Controls.Add(lblaverage);
            Controls.Add(lblcourse3);
            Controls.Add(lblcourse2);
            Controls.Add(lblcourse1);
            Controls.Add(lblphone);
            Controls.Add(lblid);
            Controls.Add(lbl_name);
            Controls.Add(txt_output);
            Controls.Add(btnreadfile);
            Controls.Add(btn_writefile);
            Name = "Bai04";
            Text = "Bai04";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_writefile;
        private Button btnreadfile;
        private TextBox txt_output;
        private Label lbl_name;
        private Label lblid;
        private Label lblphone;
        private Label lblcourse1;
        private Label lblcourse2;
        private Label lblcourse3;
        private Label lblaverage;
        private TextBox txt_name;
        private Label lbl_average2;
        private Label lbl_course3_2;
        private Label lbl_course2_2;
        private Label lbl_course1_2;
        private Label lbl_phone2;
        private Label lbl_id2;
        private Label lbl_name2;
        private TextBox txt_id;
        private TextBox txt_phone;
        private TextBox txt_course1;
        private TextBox txt_course2;
        private TextBox txt_course3;
        private TextBox txt_average;
        private TextBox txt_average2;
        private TextBox txt_course3_2;
        private TextBox txt_course2_2;
        private TextBox txt_course1_2;
        private TextBox txt_phone2;
        private TextBox txt_id2;
        private TextBox txt_name2;
        private Button btn_add;
        private Button btn_back;
        private Button btn_next;
        private Label label2;
        private Label lbl_page;
    }
}