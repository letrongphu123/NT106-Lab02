using System.IO;

namespace lab2
{
    public partial class Bai01 : Form
    {
        public Bai01()
        {
            InitializeComponent();
        }

        private async void btn_docfile_Click(object sender, EventArgs e)
        {
            //tao luong stream
            using var nguon = new FileStream("D:\\project_nt106\\lab2\\input1.txt", FileMode.Open, FileAccess.Read);

            //tao doi tuong doc file
            using var reader = new StreamReader(nguon);

            // doc file bat dong bo
            string noidung = await reader.ReadToEndAsync();

            //ghi du lieu vao textbox 
            txt_output.Text = noidung;
        }

        private async void btn_ghifile_Click(object sender, EventArgs e)
        {
            using var dich = new FileStream("D:\\project_nt106\\lab2\\output1.txt", FileMode.Create, FileAccess.Write);
            using var writer = new StreamWriter(dich);
            string noidung = txt_output.Text.ToUpper();

            await writer.WriteAsync(noidung);
        }
    }
}
