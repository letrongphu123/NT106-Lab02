﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace lab2
{
    public partial class Bai02 : Form
    {
        public Bai02()
        {
            InitializeComponent();
        }

        private async void btn_readfile_Click(object sender, EventArgs e)
        {
            // mo cua so up load file
            using (OpenFileDialog openfileDialog = new OpenFileDialog())
            {
                //neu nguoi dung mo file hoac double click vao file
                if (openfileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        //lay duong dan cua file
                        string url = openfileDialog.FileName;
                        txt_url.Text = url;
                        // doc ten file
                        txt_filename.Text = openfileDialog.SafeFileName;

                        //doc kich thuoc cua file
                        FileInfo fileinfo = new FileInfo(url);
                        txt_size.Text = $"{fileinfo.Length} Bytes";

                        //in noi dung file ra man hinh
                        using var nguon = new FileStream(openfileDialog.FileName, FileMode.Open, FileAccess.Read);
                        using var reader = new StreamReader(nguon);

                        string noidung = await reader.ReadToEndAsync();
                        txt_output.Text = noidung;

                        //dem so dong cua file
                        string[] lines = noidung.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                        txt_linecount.Text = lines.Length.ToString();

                        // dem so luong tu co trong file
                        char[] dieukien = new char[] { ' ', '\r', '\n', '\t' };
                        int wordcount = noidung.Split(dieukien, StringSplitOptions.RemoveEmptyEntries).Length; // tach chuoi thanh cac tu va dem so luong tu 
                        txt_wordcount.Text = wordcount.ToString();

                        //dem so luong ky tu (bao gom ca ky tu xuong dong)
                        txt_charactercount.Text = noidung.Length.ToString();
                    }
                    catch
                    {
                        MessageBox.Show("Lỗi khi đọc file!");
                    }
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
