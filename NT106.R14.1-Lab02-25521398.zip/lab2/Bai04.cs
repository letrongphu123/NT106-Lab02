﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows.Forms;

#pragma warning disable SYSLIB0011 // Tắt cảnh báo BinaryFormatter lỗi thời

namespace lab2
{
    public partial class Bai04 : Form
    {
        [Serializable] // Bắt buộc có để BinaryFormatter hiểu và đọc/ghi được
        public class SinhVien
        {
            public string HoTen { get; set; }
            public int MSSV { get; set; }
            public string DienThoai { get; set; }
            public float DiemMon1 { get; set; }
            public float DiemMon2 { get; set; }
            public float DiemMon3 { get; set; }
            public float DiemTrungBinh { get; set; }
        }

        private List<SinhVien> Danhsachnhap = new List<SinhVien>();
        private List<SinhVien> Danhsachdoc = new List<SinhVien>();
        private int current_index = 0;
        public Bai04()
        {
            InitializeComponent();

            // Đặt giá trị mặc định khi chưa có dữ liệu đọc file
            lbl_page.Text = "0 / 0";
        }

        private void lblcourse1_Click(object sender, EventArgs e)
        {

        }

        private void txt_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Chặn không cho ký tự hiện lên
            }
        }

        private void txt_id_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_id.Text) && txt_id.Text.Length != 8)
            {
                MessageBox.Show("Mã số sinh viên phải có đúng 8 chữ số!", "Thông báo");
                txt_id.Clear();
                txt_id.Focus();
            }
        }

        private void txt_phone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txt_phone_Leave(object sender, EventArgs e)
        {
            string phone = txt_phone.Text.Trim();
            if (!string.IsNullOrEmpty(phone))
            {
                if (phone.Length != 10 || !phone.StartsWith("0"))
                {
                    MessageBox.Show("Số điện thoại phải có 10 chữ số và bắt đầu bằng số 0! Dữ liệu đã bị xóa.", "Thông báo");
                    txt_phone.Clear();
                    txt_phone.Focus();
                }
            }
        }

        private void txt_course1_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // Nếu đã có dấu chấm rồi thì không cho gõ thêm dấu chấm thứ 2
            if (e.KeyChar == '.' && txt.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txt_course1_Leave(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (!string.IsNullOrEmpty(txt.Text))
            {
                if (float.TryParse(txt.Text, out float diem))
                {
                    if (diem < 0 || diem > 10)
                    {
                        MessageBox.Show("Điểm phải nằm trong khoảng từ 0 đến 10! Dữ liệu đã bị xóa.", "Thông báo");
                        txt.Clear();
                        txt.Focus();
                    }
                }
                else
                {
                    txt.Clear();
                }
            }
        }

        private void txt_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; //chan so va ky tu dac biet
            }
        }

        private void txt_course2_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // Nếu đã có dấu chấm rồi thì không cho gõ thêm dấu chấm thứ 2
            if (e.KeyChar == '.' && txt.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txt_course2_Leave(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (!string.IsNullOrEmpty(txt.Text))
            {
                if (float.TryParse(txt.Text, out float diem))
                {
                    if (diem < 0 || diem > 10)
                    {
                        MessageBox.Show("Điểm phải nằm trong khoảng từ 0 đến 10! Dữ liệu đã bị xóa.", "Thông báo");
                        txt.Clear();
                        txt.Focus();
                    }
                }
                else
                {
                    txt.Clear();
                }
            }
        }

        private void txt_course3_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // Nếu đã có dấu chấm rồi thì không cho gõ thêm dấu chấm thứ 2
            if (e.KeyChar == '.' && txt.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txt_course3_Leave(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (!string.IsNullOrEmpty(txt.Text))
            {
                if (float.TryParse(txt.Text, out float diem))
                {
                    if (diem < 0 || diem > 10)
                    {
                        MessageBox.Show("Điểm phải nằm trong khoảng từ 0 đến 10! Dữ liệu đã bị xóa.", "Thông báo");
                        txt.Clear();
                        txt.Focus();
                    }
                }
                else
                {
                    txt.Clear();
                }
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem các ô có bị để trống không trước khi thêm
            if (string.IsNullOrWhiteSpace(txt_name.Text) ||
                string.IsNullOrWhiteSpace(txt_id.Text) ||
                string.IsNullOrWhiteSpace(txt_phone.Text) ||
                string.IsNullOrWhiteSpace(txt_course1.Text) ||
                string.IsNullOrWhiteSpace(txt_course2.Text) ||
                string.IsNullOrWhiteSpace(txt_course3.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tất cả các thông tin!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                SinhVien sv = new SinhVien
                {
                    HoTen = txt_name.Text.Trim(),
                    MSSV = int.Parse(txt_id.Text.Trim()),
                    DienThoai = txt_phone.Text.Trim(),
                    DiemMon1 = float.Parse(txt_course1.Text.Trim()),
                    DiemMon2 = float.Parse(txt_course2.Text.Trim()),
                    DiemMon3 = float.Parse(txt_course3.Text.Trim()),
                    //DiemTrungBinh = (float.Parse(txt_course1.Text.Trim()) +
                    //float.Parse(txt_course2.Text.Trim()) +
                    //float.Parse(txt_course3.Text.Trim())) / 3f
                };

                Danhsachnhap.Add(sv);

                // Xóa trắng các ô nhập để chuẩn bị nhập sinh viên tiếp theo
                txt_name.Clear();
                txt_id.Clear();
                txt_phone.Clear();
                txt_course1.Clear();
                txt_course2.Clear();
                txt_course3.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi dữ liệu đầu vào: " + ex.Message, "Lỗi");
            }
        }

        private void btn_writefile_Click(object sender, EventArgs e)
        {
            //kiem tra danh sach sinh vien nhap vao da co sinh vien nao chua
            if (Danhsachnhap == null || Danhsachnhap.Count == 0)
            {
                MessageBox.Show("Chưa có sinh viên nào trong danh sách!");
                return;
            }

            try
            {
                //su dung binary formatter de ghi mang xuong file "input4.txt"
                using (FileStream fs = new FileStream("D:\\project_nt106\\lab2\\input4.txt", FileMode.Create, FileAccess.ReadWrite))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fs, Danhsachnhap);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi ghi file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HienThiSinhVienHienTai()
        {

            if (Danhsachdoc == null || Danhsachdoc.Count == 0)
                return;

            var sv = Danhsachdoc[current_index];

            // hien thi cac thong tin cua sinh vien
            txt_name2.Text = sv.HoTen;
            txt_id2.Text = sv.MSSV.ToString();
            txt_phone2.Text = sv.DienThoai;
            txt_course1_2.Text = sv.DiemMon1.ToString();
            txt_course2_2.Text = sv.DiemMon2.ToString();
            txt_course3_2.Text = sv.DiemMon3.ToString();
            txt_average2.Text = sv.DiemTrungBinh.ToString("0.00"); // Làm tròn điểm trung bình 2 chữ số thập phân

            // Hiển thị số trang / thứ tự sinh viên đang xem lên tiêu đề Form
            lbl_page.Text = $"{current_index + 1} / {Danhsachdoc.Count}";
        }

        private void btnreadfile_Click(object sender, EventArgs e)
        {
            //kiem tra file input4.txt da ton tai chua
            if (!File.Exists("D:\\project_nt106\\lab2\\input4.txt"))
            {
                MessageBox.Show("Không tìm thấy file!");
                return;
            }

            try
            {
                // doc mang sinh vien bang binary formatter
                using (FileStream fs = new FileStream("D:\\project_nt106\\lab2\\input4.txt", FileMode.Open))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Danhsachdoc = (List<SinhVien>)formatter.Deserialize(fs);
                }

                //tinh diem trung binh cho tung sinh vien
                foreach (var sv in Danhsachdoc)
                {
                    sv.DiemTrungBinh = (sv.DiemMon1 + sv.DiemMon2 + sv.DiemMon3) / 3f;
                }

                // 3. Ghi mảng kết quả mới (đã có điểm trung bình) xuống file "output4.txt"
                using (FileStream fs = new FileStream("D:\\project_nt106\\lab2\\output4.txt", FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fs, Danhsachdoc);
                }

                // 4. Reset về vị trí sinh viên đầu tiên và hiển thị lên màn hình
                current_index = 0;
                HienThiSinhVienHienTai();

                //in du lieu sinh vien ra man hinh
                txt_output.Clear(); // Xóa dữ liệu cũ
                int stt = 1;
                foreach (var sv in Danhsachdoc)
                {
                    // Gộp tất cả thông tin của 1 sinh viên vào chung 1 dòng, cách nhau bằng dấu gạch đứng (|) hoặc khoảng trắng
                    string line = $"{stt}. \r\n {sv.HoTen} \r\n ID: {sv.MSSV} \r\n SĐT: {sv.DienThoai} \r\n ĐTB: {sv.DiemTrungBinh:0.00}\r\n";

                    txt_output.AppendText(line);
                    stt++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đọc/xử lý file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lbl_page_Click(object sender, EventArgs e)
        {

        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            //kiem tra danh sach doc da co sv nao chua
            if (Danhsachdoc == null && Danhsachdoc.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu sinh viên!");
                return;
            }

            //neu chua phai la sinh vien cuoi cung thi tang chi so len 1
            if (current_index < Danhsachdoc.Count - 1)
            {
                current_index++;
                HienThiSinhVienHienTai();
            }
            else
            {
                MessageBox.Show("Đây là sinh viên cuối cùng trong danh sách!");
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            //kiem tra danh sach doc da co sv nao chua
            if (Danhsachdoc == null && Danhsachdoc.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu sinh viên!");
                return;
            }

            //neu chua phai la sinh vien dau tien thi giam chi so di 1
            if (current_index > 0)
            {
                current_index--;
                HienThiSinhVienHienTai();
            }
            else
            {
                MessageBox.Show("Đây là sinh viên đầu tiên trong danh sách!");
            }
        }
    }
}
