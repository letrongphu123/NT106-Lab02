﻿namespace lab2
{
    partial class Bai02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_readfile = new Button();
            button1 = new Button();
            label1 = new Label();
            lbl_filename = new Label();
            lbl_size = new Label();
            lbl_url = new Label();
            lbl_linecount = new Label();
            lbl_wordcount = new Label();
            lbl_charactercount = new Label();
            txt_filename = new TextBox();
            txt_size = new TextBox();
            txt_url = new TextBox();
            txt_linecount = new TextBox();
            txt_wordcount = new TextBox();
            txt_charactercount = new TextBox();
            txt_output = new TextBox();
            SuspendLayout();
            // 
            // btn_readfile
            // 
            btn_readfile.BackColor = SystemColors.ButtonFace;
            btn_readfile.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_readfile.Location = new Point(19, 12);
            btn_readfile.Name = "btn_readfile";
            btn_readfile.Size = new Size(360, 37);
            btn_readfile.TabIndex = 0;
            btn_readfile.Text = "Read From File";
            btn_readfile.UseVisualStyleBackColor = false;
            btn_readfile.Click += btn_readfile_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(19, 387);
            button1.Name = "button1";
            button1.Size = new Size(360, 51);
            button1.TabIndex = 1;
            button1.Text = "EXIT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(262, 110);
            label1.Name = "label1";
            label1.Size = new Size(50, 20);
            label1.TabIndex = 2;
            label1.Text = "label1";
            // 
            // lbl_filename
            // 
            lbl_filename.AutoSize = true;
            lbl_filename.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_filename.ForeColor = SystemColors.Highlight;
            lbl_filename.Location = new Point(19, 80);
            lbl_filename.Name = "lbl_filename";
            lbl_filename.Size = new Size(92, 25);
            lbl_filename.TabIndex = 3;
            lbl_filename.Text = "File name";
            // 
            // lbl_size
            // 
            lbl_size.AutoSize = true;
            lbl_size.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_size.ForeColor = SystemColors.Highlight;
            lbl_size.Location = new Point(19, 128);
            lbl_size.Name = "lbl_size";
            lbl_size.Size = new Size(45, 25);
            lbl_size.TabIndex = 4;
            lbl_size.Text = "Size";
            // 
            // lbl_url
            // 
            lbl_url.AutoSize = true;
            lbl_url.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_url.ForeColor = SystemColors.Highlight;
            lbl_url.Location = new Point(19, 177);
            lbl_url.Name = "lbl_url";
            lbl_url.Size = new Size(45, 25);
            lbl_url.TabIndex = 5;
            lbl_url.Text = "URL";
            // 
            // lbl_linecount
            // 
            lbl_linecount.AutoSize = true;
            lbl_linecount.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_linecount.ForeColor = SystemColors.Highlight;
            lbl_linecount.Location = new Point(19, 228);
            lbl_linecount.Name = "lbl_linecount";
            lbl_linecount.Size = new Size(100, 25);
            lbl_linecount.TabIndex = 6;
            lbl_linecount.Text = "Line count";
            // 
            // lbl_wordcount
            // 
            lbl_wordcount.AutoSize = true;
            lbl_wordcount.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_wordcount.ForeColor = SystemColors.Highlight;
            lbl_wordcount.Location = new Point(19, 278);
            lbl_wordcount.Name = "lbl_wordcount";
            lbl_wordcount.Size = new Size(111, 25);
            lbl_wordcount.TabIndex = 7;
            lbl_wordcount.Text = "Word count";
            // 
            // lbl_charactercount
            // 
            lbl_charactercount.AutoSize = true;
            lbl_charactercount.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_charactercount.ForeColor = SystemColors.Highlight;
            lbl_charactercount.Location = new Point(19, 331);
            lbl_charactercount.Name = "lbl_charactercount";
            lbl_charactercount.Size = new Size(143, 25);
            lbl_charactercount.TabIndex = 8;
            lbl_charactercount.Text = "Character count";
            // 
            // txt_filename
            // 
            txt_filename.Location = new Point(176, 81);
            txt_filename.Name = "txt_filename";
            txt_filename.ReadOnly = true;
            txt_filename.Size = new Size(203, 27);
            txt_filename.TabIndex = 9;
            // 
            // txt_size
            // 
            txt_size.Location = new Point(176, 129);
            txt_size.Name = "txt_size";
            txt_size.ReadOnly = true;
            txt_size.Size = new Size(203, 27);
            txt_size.TabIndex = 10;
            // 
            // txt_url
            // 
            txt_url.Location = new Point(176, 178);
            txt_url.Name = "txt_url";
            txt_url.ReadOnly = true;
            txt_url.Size = new Size(203, 27);
            txt_url.TabIndex = 11;
            // 
            // txt_linecount
            // 
            txt_linecount.Location = new Point(176, 226);
            txt_linecount.Name = "txt_linecount";
            txt_linecount.ReadOnly = true;
            txt_linecount.Size = new Size(203, 27);
            txt_linecount.TabIndex = 12;
            // 
            // txt_wordcount
            // 
            txt_wordcount.Location = new Point(176, 279);
            txt_wordcount.Name = "txt_wordcount";
            txt_wordcount.ReadOnly = true;
            txt_wordcount.Size = new Size(203, 27);
            txt_wordcount.TabIndex = 13;
            // 
            // txt_charactercount
            // 
            txt_charactercount.Location = new Point(176, 329);
            txt_charactercount.Name = "txt_charactercount";
            txt_charactercount.ReadOnly = true;
            txt_charactercount.Size = new Size(203, 27);
            txt_charactercount.TabIndex = 14;
            // 
            // txt_output
            // 
            txt_output.BackColor = SystemColors.ControlText;
            txt_output.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_output.ForeColor = SystemColors.HotTrack;
            txt_output.Location = new Point(406, 12);
            txt_output.Multiline = true;
            txt_output.Name = "txt_output";
            txt_output.ReadOnly = true;
            txt_output.Size = new Size(382, 426);
            txt_output.TabIndex = 15;
            // 
            // Bai02
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_output);
            Controls.Add(txt_charactercount);
            Controls.Add(txt_wordcount);
            Controls.Add(txt_linecount);
            Controls.Add(txt_url);
            Controls.Add(txt_size);
            Controls.Add(txt_filename);
            Controls.Add(lbl_charactercount);
            Controls.Add(lbl_wordcount);
            Controls.Add(lbl_linecount);
            Controls.Add(lbl_url);
            Controls.Add(lbl_size);
            Controls.Add(lbl_filename);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(btn_readfile);
            Name = "Bai02";
            Text = "Bai02";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_readfile;
        private Button button1;
        private Label label1;
        private Label lbl_filename;
        private Label lbl_size;
        private Label lbl_url;
        private Label lbl_linecount;
        private Label lbl_wordcount;
        private Label lbl_charactercount;
        private TextBox txt_filename;
        private TextBox txt_size;
        private TextBox txt_url;
        private TextBox txt_linecount;
        private TextBox txt_wordcount;
        private TextBox txt_charactercount;
        private TextBox txt_output;
    }
}