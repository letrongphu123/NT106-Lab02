﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace lab2
{
    public partial class Bai07 : Form
    {
        string path = @"D:\";
        public Bai07()
        {
            InitializeComponent();

            if (Directory.Exists(path))
            {
                TreeNode root = new TreeNode() { Text = path, Tag = path };  //tao node goc
                LoadExplorer(root);                             // thuc hien tim tat ca cac thu muc con trong node goc
                treeView_explorer.Nodes.Add(root);              // them node goc vao treeview
            }
        }

        void LoadExplorer(TreeNode root)
        {
            if (root == null || root.Tag == null)
                return;
            try
            {
                //tao doi tuong duong dan cu the
                DirectoryInfo dirinfo = new DirectoryInfo(root.Tag.ToString());

                //quet ta cac thu muc con
                var folderlist = dirinfo.GetDirectories();

                //duyet tung thu muc con trong danh sach thu muc quet duoc
                foreach (DirectoryInfo item in folderlist)
                {
                    if (Directory.Exists(item.FullName))  //kiem tra thu muc do co ton tai hay khong
                    {
                        TreeNode node = new TreeNode(item.Name); //neu thu muc ton tai thi tao them 1 node voi ten thu muc
                        node.Tag = item.FullName;
                        root.Nodes.Add(node);                    //them node do vao thu muc goc
                        LoadExplorer(node);                      // goi de quy de tiep tuc tim cac thu muc con ben trong cua node do
                    }
                }

                //quet cac file ben trong thu muc con
                var filelist = dirinfo.GetFiles();
                foreach (FileInfo file in filelist)
                {
                    TreeNode filenode = new TreeNode(file.Name);
                    filenode.Tag = file.FullName;
                    root.Nodes.Add(filenode);   //them file vao cay
                }
            }
            catch
            {
                return;
            }
        }

        private void treeView_odia_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private async void treeView_explorer_DoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Bai07_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private async void treeView_explorer_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //Kiem tra node co chua url va file ton tai khong
            if (e.Node == null || e.Node.Tag == null || !File.Exists(e.Node.Tag.ToString()))
                return;

            string filepath = (string)e.Node.Tag;                  // lay duong dan cua node
            string duoifile = Path.GetExtension(filepath).ToLower(); // lay duoi cua file

            //giai phong anh cu (neu co)
            try
            {
                if (pictureBox_output.Image != null)
                {
                    pictureBox_output.Image.Dispose();
                    pictureBox_output.Image = null;
                }

                //TH1: neu la file text
                if (duoifile == ".txt" || duoifile == ".json" || duoifile == ".log")
                {
                    //bac textbox_output va tat picturebox_output 
                    textBox_output.Visible = true;
                    pictureBox_output.Visible = false;

                    //doc file va ghi ra man hinh
                    using var nguon = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                    using var reader = new StreamReader(nguon);

                    string noidung = await reader.ReadToEndAsync();
                    textBox_output.Text = noidung;
                }

                //TH2: file anh
                else if (duoifile == ".png" || duoifile == ".jpeg" || duoifile == ".jpg" || duoifile == ".bmp")
                {
                    //tat textbox_output va bac picturebox_output 
                    textBox_output.Visible = false;
                    pictureBox_output.Visible = true;

                    using (FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read))
                    {
                        using (MemoryStream ms = new MemoryStream())
                        {
                            await fs.CopyToAsync(ms); //copy sang ram
                            pictureBox_output.Image = System.Drawing.Image.FromStream(ms); // hien thi anh ra man hinh
                            pictureBox_output.SizeMode = PictureBoxSizeMode.Zoom; //can chinh anh theo khung 
                        }
                    }
                }

                //cac truong hop file dang khac
                else
                {
                    MessageBox.Show("Định dạng file không được hỗ trợ!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi mở tệp tin: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
