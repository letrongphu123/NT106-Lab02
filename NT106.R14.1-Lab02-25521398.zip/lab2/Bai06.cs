﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security.AccessControl;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace lab2
{
    public partial class Bai06 : Form
    {
        //khai bao ten file co so du lieu va chuoi ket noi
        private string dbname = "quan_an.db";
        private string connectionString;

        private string imagepath = "";
        public Bai06()
        {
            InitializeComponent();

            //tao chuoi ket noi
            connectionString = $"Data Source=quan_an.db;";

            //goi ham tao co so du lieu va cac bang
            TaoCoSoDuLieuVaBang();
        }

        private async void Bai06_Load(object sender, EventArgs e)
        {
            await LoadDanhSachNguoiCungCap();
            await LoadMenuListViewAsync();
        }

        //ham tao co so du lieu va bang
        private void TaoCoSoDuLieuVaBang()
        {
            try
            {
                //mo ket noi va thuc hien cau lenh sql tao bang
                using (SqliteConnection connect = new SqliteConnection(connectionString))
                {
                    connect.Open();

                    //cau lenh tao bang NGUOIDUNG
                    string sqlNGUOIDUNG = @"CREATE TABLE IF NOT EXISTS NGUOIDUNG (
                                                IDNCC INTEGER PRIMARY KEY AUTOINCREMENT,
                                                HoVaTen TEXT NOT NULL,
                                                QuyenHan TEXT
                                                );";

                    //cau lenh tao bang MONAN
                    string sqlMONAN = @"CREATE TABLE IF NOT EXISTS MONAN (
                                            IDMA INTEGER PRIMARY KEY AUTOINCREMENT,
                                            TenMonAn TEXT NOT NULL,
                                            HinhAnh TEXT,
                                            IDNCC INT,
                                            FOREIGN KEY (IDNCC) REFERENCES NGUOIDUNG(IDNCC)
                                            );";

                    //thuc thi cau lenh tao bang NGUOIDUNG
                    using (SqliteCommand cmd1 = new SqliteCommand(sqlNGUOIDUNG, connect))
                    {
                        cmd1.ExecuteNonQuery();
                    }

                    //thuc thi cau lenh tao bang MONAN
                    using (SqliteCommand cmd2 = new SqliteCommand(sqlMONAN, connect))
                    {
                        cmd2.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txt_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; //chan so va ky tu dac biet
            }
        }

        private async void btn_add_Click(object sender, EventArgs e)
        {
            string ten = txt_name.Text.Trim();
            string role = cob_role.Text.Trim();

            //kiem tra nguoi dung da nhap ten hay chua
            if (string.IsNullOrEmpty(ten))
            {
                MessageBox.Show("Vui lòng nhập tên người dùng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // khoa nut add lai luc dang xu ly tranh nguoi dung click nhieu lan
                btn_addnguoidung.Enabled = false;

                using (SqliteConnection connect = new SqliteConnection(connectionString))
                {
                    //mo ket noi bat dong bo
                    await connect.OpenAsync();

                    string query = @"INSERT INTO NGUOIDUNG (HoVaTen, QuyenHan) VALUES(@ten, @quyen)";

                    using (SqliteCommand cmd = new SqliteCommand(query, connect))
                    {
                        cmd.Parameters.AddWithValue("@ten", ten);
                        cmd.Parameters.AddWithValue("@quyen", role);

                        //thuc thi cau lenh insert
                        await cmd.ExecuteNonQueryAsync();

                        //xoa trang o nhap
                        txt_name.Clear();
                        if (cob_role.Items.Count > 0)
                            cob_role.SelectedIndex = 0;

                        await LoadDanhSachNguoiCungCap(); //load du ten nguoi dung len phia them mon an
                    }
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm vào cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Mở lại nút Add (dù thành công hay thất bại)
                btn_addnguoidung.Enabled = true;
            }
        }

        private void txt_tenmonan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; //chan so va ky tu dac biet
            }
        }

        private async Task LoadDanhSachNguoiCungCap()
        {
            try
            {
                using (SqliteConnection connect = new SqliteConnection(connectionString))
                {
                    await connect.OpenAsync();

                    //lay IDNCC va HoVaTen tu bang NGUOIDUNG
                    string query = @"SELECT IDNCC, HoVaTen FROM NGUOIDUNG";

                    using (SqliteCommand cmd = new SqliteCommand(query, connect))
                    {
                        using (SqliteDataReader reader = (SqliteDataReader)await cmd.ExecuteReaderAsync())
                        {
                            //tao dnah sach tam de chua du lieu
                            var listnguoidung = new List<KeyValuePair<int, string>>();

                            while (await reader.ReadAsync())
                            {
                                int id = reader.GetInt32(0);
                                string ten = reader.GetString(1);
                                listnguoidung.Add(new KeyValuePair<int, string>(id, ten));
                            }

                            //gan cho combo box 
                            cob_ncc.DataSource = null;
                            cob_ncc.DataSource = listnguoidung;
                            cob_ncc.DisplayMember = "value"; //hien thi ten nguoi cung cap
                            cob_ncc.ValueMember = "Key"; // luu ngam IDNCC ben duoi

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải danh sách người cung cấp! " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                //loc cac dinh dang pho bien
                dialog.Filter = "Image Files (*.jpg; *.jpeg; *.png)| *.jpg; *.jpeg; *.png";
                dialog.Title = "Chọn hình ảnh món ăn";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    //lay duong dan 
                    imagepath = dialog.FileName;
                }
            }
        }

        private async void btn_addmonan_Click(object sender, EventArgs e)
        {
            //lay du lieu
            string tenmonan = txt_tenmonan.Text.Trim();

            int idncc = 0;
            if (cob_ncc.SelectedValue != null)
            {
                idncc = Convert.ToInt32(cob_ncc.SelectedValue);
            }

            //kiem tra tinh hop le cua du lieu
            if (string.IsNullOrEmpty(tenmonan))
            {
                MessageBox.Show("Vui lòng nhập tên món ăn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (idncc == 0)
            {
                MessageBox.Show("Vui lòng chọn người cung cấp hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                //khoa nut add
                btn_addmonan.Enabled = false;
                using (SqliteConnection connect = new SqliteConnection(connectionString))
                {
                    await connect.OpenAsync();

                    string query = @"INSERT INTO MONAN (TenMonAn, HinhAnh, IDNCC) VALUES (@ten, @hinhanh, @idncc)";

                    using (SqliteCommand cmd = new SqliteCommand(query, connect))
                    {
                        cmd.Parameters.AddWithValue("@ten", tenmonan);
                        cmd.Parameters.AddWithValue("@hinhanh", imagepath);
                        cmd.Parameters.AddWithValue("@idncc", idncc);

                        //thuc thi cau lenh xuong co so du lieu
                        await cmd.ExecuteNonQueryAsync();

                        //reset lai cac o nhap
                        txt_tenmonan.Clear();
                        imagepath = "";

                        //hoi ham load lai listview 
                        await LoadMenuListViewAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm món ăn vào cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Mở lại nút Add
                btn_addmonan.Enabled = true;
            }
        }

        private async Task LoadMenuListViewAsync()
        {
            //xoa du lieu cu tren listview va imagelist de tranh trung lap
            lv_menu.Items.Clear();
            imageList1.Images.Clear();

            try
            {
                using (SqliteConnection connect = new SqliteConnection(connectionString))
                {
                    await connect.OpenAsync();

                    // Câu lệnh truy vấn lấy danh sách món ăn
                    string query = @"SELECT IDMA, TenMonAn, HinhAnh FROM MonAn";

                    using (SqliteCommand cmd = new SqliteCommand(query, connect))
                    {
                        using (SqliteDataReader reader = (SqliteDataReader)await cmd.ExecuteReaderAsync())
                        {
                            int index = 0; //bien dem vi tri anh tuong ung trong imagelist
                            while (await reader.ReadAsync())
                            {
                                string idma = reader["IDMA"].ToString();
                                string ten = reader["TenMonAn"].ToString();
                                string hinhanhpath = reader["HinhAnh"].ToString();

                                //tai hinh anh tu path da luu
                                Image img = null;
                                if (!string.IsNullOrEmpty(hinhanhpath) && File.Exists(hinhanhpath))
                                {
                                    try
                                    {
                                        //doc file anh
                                        img = Image.FromFile(hinhanhpath);
                                    }
                                    catch
                                    {
                                        img = null; //loi thi bo qua
                                    }
                                }

                                //dua anh vao imagelist
                                if (img != null)
                                {
                                    imageList1.Images.Add(img); //neu khong co anh thi tao mot o vuong trang lam mac dinh
                                }

                                else
                                {
                                    imageList1.Images.Add(new Bitmap(64, 64));
                                }

                                //tao mot item cho listview 
                                ListViewItem item = new ListViewItem();
                                item.Text = ten;                //hien thi ten mon an ben duoi anh
                                item.ImageIndex = index;        //gan vi tri anh tuong ung voi imagelist vua them vao
                                item.Tag = idma;                //luu ngam IDMA vao tag

                                //them item vao listview
                                lv_menu.Items.Add(item);
                                index++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải danh sách thực đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btn_timmonan_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Xóa tất cả các trạng thái đang chọn (bỏ tô sáng cũ) trên ListView trước
                foreach (ListViewItem itm in lv_menu.Items)
                {
                    itm.Selected = false;
                }

                using (SqliteConnection connect = new SqliteConnection(connectionString))
                {
                    await connect.OpenAsync();

                    //lay ngau nhien 1 mon an ket hop lay ten nguoi dong gop tu bang NGUOIDUNG
                    string query = @"SELECT MONAN.IDMA, MONAN.TenMonAn, MONAN.HINHANH, NGUOIDUNG.HoVaTen
                                    FROM MONAN LEFT JOIN NGUOIDUNG ON MONAN.IDNCC = NGUOIDUNG.IDNCC
                                    ORDER BY RANDOM() LIMIT 1;";

                    using (SqliteCommand cmd = new SqliteCommand(query, connect))
                    {
                        using (SqliteDataReader reader = (SqliteDataReader)await cmd.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                string idma = reader["IDMA"].ToString();
                                string ten = reader["TenMonAn"].ToString();
                                string ncc = reader["HoVaTen"] != DBNull.Value ? reader["HoVaTen"].ToString() : "Không rõ";

                                //tu dong tim kiem va to sang dung mon an do tren listview
                                bool found = false;
                                foreach (ListViewItem item in lv_menu.Items)
                                {
                                    //kiem tra dua vao tag
                                    if (item.Tag != null && item.Tag.ToString() == idma)
                                    {
                                        item.Selected = true;       //to sang item
                                        item.EnsureVisible();       //tim den vi tri cua mon an neu danh sach qua dai
                                        lv_menu.Focus();            // giup thay ro listview thoi =))
                                        found = true;
                                        break;
                                    }
                                }

                                MessageBox.Show($"Món ăn hôm nay : {ten}\nDo bạn {ncc} đóng góp!", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Thực đơn hiện đang trống! Vui lòng thêm món ăn trước.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi chọn món ăn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
