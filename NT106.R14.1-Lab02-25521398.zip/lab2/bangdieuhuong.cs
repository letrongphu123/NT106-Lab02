﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace lab2
{
    public partial class bangdieuhuong : Form
    {
        public bangdieuhuong()
        {
            InitializeComponent();
        }

        private void btn_bai01_Click(object sender, EventArgs e)
        {
            Form bai01 = new Bai01();
            bai01.Show();
        }

        private void btn_bai02_Click(object sender, EventArgs e)
        {
            Form bai02 = new Bai02();
            bai02.Show();
        }

        private void btn_bai03_Click(object sender, EventArgs e)
        {
            Form bai03 = new Bai03();
            bai03.Show();
        }

        private void btn_bai04_Click(object sender, EventArgs e)
        {
            Form bai04 = new Bai04();
            bai04.Show();
        }

        private void btn_bai05_Click(object sender, EventArgs e)
        {
            Form bai05 = new Bai05();
            bai05.Show();
        }

        private void btn_bai06_Click(object sender, EventArgs e)
        {
            Form bai06 = new Bai06();
            bai06.Show();
        }

        private void btn_bai07_Click(object sender, EventArgs e)
        {
            Form bai07 = new Bai07();
            bai07.Show();
        }
    }
}
