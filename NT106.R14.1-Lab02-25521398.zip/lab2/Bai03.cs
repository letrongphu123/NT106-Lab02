﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace lab2
{
    public partial class Bai03 : Form
    {
        private List<string> _danhSachKetQua = new List<string>();
        public Bai03()
        {
            InitializeComponent();
        }

        private async void btn_docfile_Click(object sender, EventArgs e)
        {
            string filepath = "D:\\project_nt106\\lab2\\input3.txt";

            if (!File.Exists(filepath))
            {
                MessageBox.Show($"Không tìm thấy file '{filepath}'!",
                                "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Xóa dữ liệu cũ trên TextBox và danh sach cung voi khoa nut doc file
            txt_output.Clear();
            _danhSachKetQua.Clear();
            btn_docfile.Enabled = false;

            try
            {
                BoTinhToanBieuThuc botinhtoan = new BoTinhToanBieuThuc();

                // Dùng FileStream + StreamReader để ĐỌC file bất đồng bộ
                using (FileStream fileStreamInput = new FileStream(filepath, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize: 4096, useAsync: true))
                using (StreamReader reader = new StreamReader(fileStreamInput, Encoding.UTF8))
                {
                    string dòng;
                    while ((dòng = await reader.ReadLineAsync()) != null)
                    {
                        if (string.IsNullOrWhiteSpace(dòng)) continue;

                        string kếtQuảDòng = "";
                        try
                        {
                            double kếtQuả = botinhtoan.TinhGiaTri(dòng);

                            // giúp loại bỏ các số 0 thừa, ví dụ: 10.0 thành 10)
                            string kếtQuảĐãĐịnhDạng = kếtQuả.ToString("0.##############");
                            kếtQuảDòng = $"{dòng.Trim()} = {kếtQuảĐãĐịnhDạng}";
                        }
                        catch (Exception ex)
                        {
                            kếtQuảDòng = $"{dòng.Trim()} = Lỗi biểu thức ({ex.Message})";
                        }

                        // Lưu vào danh sách toàn cục
                        _danhSachKetQua.Add(kếtQuảDòng);

                        // Hiển thị trực tiếp lên TextBox
                        txt_output.AppendText(kếtQuảDòng + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi hệ thống: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btn_docfile.Enabled = true;
            }

        }

        private async void btn_ghifile_Click(object sender, EventArgs e)
        {
            //khoa nut 
            btn_ghifile.Enabled = false;

            if(string.IsNullOrEmpty(txt_output.Text))
            {
                MessageBox.Show("Nội dung trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                string noidung = txt_output.Text;
                string filepath = "D:\\project_nt106\\lab2\\output3.txt";
                using (FileStream fs = new FileStream(filepath, FileMode.Create, FileAccess.Write))
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    await writer.WriteAsync(noidung);
                }
                // Thông báo thành công cho người dùng biết
                MessageBox.Show("Ghi file thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
            catch(Exception ex)
            {
                MessageBox.Show("Lỗi ghi file", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                //mo lai nut 
                btn_ghifile.Enabled = true;
            }
        }
    }
}

public class BoTinhToanBieuThuc
{
    private string _chuoiBieuThuc;
    private int _viTri;

    public double TinhGiaTri(string bieuThuc)
    {
        // Chuẩn hóa biểu thức: Thay dấu trừ đặc biệt (–) thành (-) và xóa khoảng trắng
        _chuoiBieuThuc = bieuThuc.Replace("–", "-").Replace(" ", "");
        _viTri = 0;

        double ketQua = XuyLyCongTru();
        return ketQua;
    }

    // 1. Cấp ưu tiên thấp nhất: Phép Cộng (+) và Trừ (-)
    private double XuyLyCongTru()
    {
        double giaTri = XuLyNhanChia(); // Lấy giá trị của cụm phép tính bên trái
        while (_viTri < _chuoiBieuThuc.Length)
        {
            char toanTu = _chuoiBieuThuc[_viTri];
            if (toanTu == '+' || toanTu == '-')
            {
                _viTri++; // Chuyển sang ký tự tiếp theo
                double giaTriTiepTheo = XuLyNhanChia(); // Lấy giá trị của cụm bên phải
                if (toanTu == '+') giaTri += giaTriTiepTheo;
                else giaTri -= giaTriTiepTheo;
            }
            else
            {
                break; // Nếu gặp ký tự khác (+ hoặc -) thì dừng vòng lặp
            }
        }
        return giaTri;
    }

    // 2. Cấp ưu tiên trung bình: Phép Nhân (*) và Chia (/)
    private double XuLyNhanChia()
    {
        double giaTri = XuLySoVaNgoac(); // Lấy giá trị con số hoặc ngoặc đơn
        while (_viTri < _chuoiBieuThuc.Length)
        {
            char toanTu = _chuoiBieuThuc[_viTri];
            if (toanTu == '*' || toanTu == '/')
            {
                _viTri++; // Chuyển sang ký tự tiếp theo
                double giaTriTiepTheo = XuLySoVaNgoac();
                if (toanTu == '*') giaTri *= giaTriTiepTheo;
                else giaTri /= giaTriTiepTheo;
            }
            else
            {
                break;
            }
        }
        return giaTri;
    }

    // 3. Cấp ưu tiên cao nhất: Số, Dấu ngoặc đơn () và Dấu âm (-)
    private double XuLySoVaNgoac()
    {
        // Xử lý trường hợp số âm (ví dụ: -5)
        if (_viTri < _chuoiBieuThuc.Length && _chuoiBieuThuc[_viTri] == '-')
        {
            _viTri++;
            return -XuLySoVaNgoac();
        }

        // Xử lý dấu cộng đơn nguyên (ví dụ: +5)
        if (_viTri < _chuoiBieuThuc.Length && _chuoiBieuThuc[_viTri] == '+')
        {
            _viTri++;
            return XuLySoVaNgoac();
        }

        // Xử lý biểu thức bên trong dấu ngoặc đơn ( ... )
        if (_viTri < _chuoiBieuThuc.Length && _chuoiBieuThuc[_viTri] == '(')
        {
            _viTri++; // Bỏ qua dấu mở ngoặc '('
            double giaTriTrongNgoac = XuyLyCongTru(); // Tính lại từ đầu trong ngoặc
            if (_viTri < _chuoiBieuThuc.Length && _chuoiBieuThuc[_viTri] == ')')
            {
                _viTri++; // Bỏ qua dấu đóng ngoặc ')'
            }
            return giaTriTrongNgoac;
        }

        // Đọc từng chữ số và dấu chấm thập phân
        int viTriBatDau = _viTri;
        while (_viTri < _chuoiBieuThuc.Length && (char.IsDigit(_chuoiBieuThuc[_viTri]) || _chuoiBieuThuc[_viTri] == '.'))
        {
            _viTri++;
        }

        // Nếu không đọc được con số nào thì báo lỗi
        if (viTriBatDau == _viTri)
        {
            throw new Exception($"Lỗi cú pháp tại vị trí {_viTri}");
        }

        // Cắt chuỗi lấy ra số hoàn chỉnh và chuyển thành kiểu double
        string chuoiSo = _chuoiBieuThuc.Substring(viTriBatDau, _viTri - viTriBatDau);
        return double.Parse(chuoiSo, CultureInfo.InvariantCulture);
    }
}
