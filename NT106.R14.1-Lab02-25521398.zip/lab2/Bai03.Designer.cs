﻿namespace lab2
{
    partial class Bai03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_tittle = new Label();
            txt_output = new TextBox();
            btn_docfile = new Button();
            btn_ghifile = new Button();
            SuspendLayout();
            // 
            // lbl_tittle
            // 
            lbl_tittle.AutoSize = true;
            lbl_tittle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_tittle.Location = new Point(251, 22);
            lbl_tittle.Name = "lbl_tittle";
            lbl_tittle.Size = new Size(295, 41);
            lbl_tittle.TabIndex = 0;
            lbl_tittle.Text = "Tính toán biểu thức";
            // 
            // txt_output
            // 
            txt_output.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_output.Location = new Point(127, 77);
            txt_output.Multiline = true;
            txt_output.Name = "txt_output";
            txt_output.ReadOnly = true;
            txt_output.Size = new Size(561, 265);
            txt_output.TabIndex = 1;
            // 
            // btn_docfile
            // 
            btn_docfile.BackColor = SystemColors.ActiveCaption;
            btn_docfile.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_docfile.Location = new Point(190, 371);
            btn_docfile.Name = "btn_docfile";
            btn_docfile.Size = new Size(103, 50);
            btn_docfile.TabIndex = 2;
            btn_docfile.Text = "Đọc file";
            btn_docfile.UseVisualStyleBackColor = false;
            btn_docfile.Click += btn_docfile_Click;
            // 
            // btn_ghifile
            // 
            btn_ghifile.BackColor = SystemColors.ActiveCaption;
            btn_ghifile.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_ghifile.Location = new Point(504, 371);
            btn_ghifile.Name = "btn_ghifile";
            btn_ghifile.Size = new Size(103, 50);
            btn_ghifile.TabIndex = 3;
            btn_ghifile.Text = "Ghi file";
            btn_ghifile.UseVisualStyleBackColor = false;
            btn_ghifile.Click += btn_ghifile_Click;
            // 
            // Bai03
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_ghifile);
            Controls.Add(btn_docfile);
            Controls.Add(txt_output);
            Controls.Add(lbl_tittle);
            Name = "Bai03";
            Text = "Bai03";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_tittle;
        private TextBox txt_output;
        private Button btn_docfile;
        private Button btn_ghifile;
    }
}