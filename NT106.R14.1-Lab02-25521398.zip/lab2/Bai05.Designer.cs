﻿namespace lab2
{
    partial class Bai05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_tittle = new Label();
            txt_output = new TextBox();
            lbl_name = new Label();
            txt_name = new MaskedTextBox();
            cmb_tenphim = new ComboBox();
            lbl_phim = new Label();
            cmb_phongchieu = new ComboBox();
            lbl_phongve = new Label();
            clb_ghengoi = new CheckedListBox();
            lbl_ghengoi = new Label();
            btn_datve = new Button();
            btn_docfile = new Button();
            btn_ghifile = new Button();
            pgb_tientrinh = new ProgressBar();
            SuspendLayout();
            // 
            // lbl_tittle
            // 
            lbl_tittle.AutoSize = true;
            lbl_tittle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_tittle.Location = new Point(245, 6);
            lbl_tittle.Name = "lbl_tittle";
            lbl_tittle.Size = new Size(309, 41);
            lbl_tittle.TabIndex = 1;
            lbl_tittle.Text = "QUẢN LÝ PHÒNG VÉ";
            // 
            // txt_output
            // 
            txt_output.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_output.Location = new Point(427, 67);
            txt_output.Multiline = true;
            txt_output.Name = "txt_output";
            txt_output.ReadOnly = true;
            txt_output.ScrollBars = ScrollBars.Vertical;
            txt_output.Size = new Size(343, 220);
            txt_output.TabIndex = 2;
            // 
            // lbl_name
            // 
            lbl_name.AutoSize = true;
            lbl_name.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_name.Location = new Point(25, 67);
            lbl_name.Name = "lbl_name";
            lbl_name.Size = new Size(96, 28);
            lbl_name.TabIndex = 3;
            lbl_name.Text = "Họ và tên";
            // 
            // txt_name
            // 
            txt_name.Location = new Point(143, 71);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(239, 27);
            txt_name.TabIndex = 4;
            // 
            // cmb_tenphim
            // 
            cmb_tenphim.FormattingEnabled = true;
            cmb_tenphim.Location = new Point(143, 123);
            cmb_tenphim.Name = "cmb_tenphim";
            cmb_tenphim.Size = new Size(239, 28);
            cmb_tenphim.TabIndex = 5;
            cmb_tenphim.SelectedIndexChanged += cmb_tenphim_SelectedIndexChanged;
            // 
            // lbl_phim
            // 
            lbl_phim.AutoSize = true;
            lbl_phim.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_phim.Location = new Point(25, 123);
            lbl_phim.Name = "lbl_phim";
            lbl_phim.Size = new Size(56, 28);
            lbl_phim.TabIndex = 6;
            lbl_phim.Text = "Phim";
            // 
            // cmb_phongchieu
            // 
            cmb_phongchieu.FormattingEnabled = true;
            cmb_phongchieu.Location = new Point(143, 175);
            cmb_phongchieu.Name = "cmb_phongchieu";
            cmb_phongchieu.Size = new Size(239, 28);
            cmb_phongchieu.TabIndex = 7;
            // 
            // lbl_phongve
            // 
            lbl_phongve.AutoSize = true;
            lbl_phongve.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_phongve.Location = new Point(25, 175);
            lbl_phongve.Name = "lbl_phongve";
            lbl_phongve.Size = new Size(94, 28);
            lbl_phongve.TabIndex = 8;
            lbl_phongve.Text = "Phòng vé";
            // 
            // clb_ghengoi
            // 
            clb_ghengoi.FormattingEnabled = true;
            clb_ghengoi.Location = new Point(143, 233);
            clb_ghengoi.Name = "clb_ghengoi";
            clb_ghengoi.Size = new Size(239, 136);
            clb_ghengoi.TabIndex = 9;
            clb_ghengoi.SelectedIndexChanged += clb_ghengoi_SelectedIndexChanged;
            // 
            // lbl_ghengoi
            // 
            lbl_ghengoi.AutoSize = true;
            lbl_ghengoi.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_ghengoi.Location = new Point(25, 233);
            lbl_ghengoi.Name = "lbl_ghengoi";
            lbl_ghengoi.Size = new Size(92, 28);
            lbl_ghengoi.TabIndex = 10;
            lbl_ghengoi.Text = "Ghế ngồi";
            // 
            // btn_datve
            // 
            btn_datve.BackColor = SystemColors.ActiveCaption;
            btn_datve.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_datve.Location = new Point(427, 319);
            btn_datve.Name = "btn_datve";
            btn_datve.Size = new Size(103, 50);
            btn_datve.TabIndex = 11;
            btn_datve.Text = "Đặt vé";
            btn_datve.UseVisualStyleBackColor = false;
            btn_datve.Click += btn_datve_Click;
            // 
            // btn_docfile
            // 
            btn_docfile.BackColor = SystemColors.ActiveCaption;
            btn_docfile.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_docfile.Location = new Point(545, 319);
            btn_docfile.Name = "btn_docfile";
            btn_docfile.Size = new Size(103, 50);
            btn_docfile.TabIndex = 12;
            btn_docfile.Text = "Đọc File";
            btn_docfile.UseVisualStyleBackColor = false;
            btn_docfile.Click += btn_docfile_Click;
            // 
            // btn_ghifile
            // 
            btn_ghifile.BackColor = SystemColors.ActiveCaption;
            btn_ghifile.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_ghifile.Location = new Point(667, 319);
            btn_ghifile.Name = "btn_ghifile";
            btn_ghifile.Size = new Size(103, 50);
            btn_ghifile.TabIndex = 13;
            btn_ghifile.Text = "Ghi File";
            btn_ghifile.UseVisualStyleBackColor = false;
            btn_ghifile.Click += btn_ghifile_Click;
            // 
            // pgb_tientrinh
            // 
            pgb_tientrinh.Location = new Point(299, 198);
            pgb_tientrinh.Name = "pgb_tientrinh";
            pgb_tientrinh.Size = new Size(204, 29);
            pgb_tientrinh.TabIndex = 14;
            // 
            // Bai05
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pgb_tientrinh);
            Controls.Add(btn_ghifile);
            Controls.Add(btn_docfile);
            Controls.Add(btn_datve);
            Controls.Add(lbl_ghengoi);
            Controls.Add(clb_ghengoi);
            Controls.Add(lbl_phongve);
            Controls.Add(cmb_phongchieu);
            Controls.Add(lbl_phim);
            Controls.Add(cmb_tenphim);
            Controls.Add(txt_name);
            Controls.Add(lbl_name);
            Controls.Add(txt_output);
            Controls.Add(lbl_tittle);
            Name = "Bai05";
            Text = "Bai05";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_tittle;
        private TextBox txt_output;
        private Label lbl_name;
        private MaskedTextBox txt_name;
        private ComboBox cmb_tenphim;
        private Label lbl_phim;
        private ComboBox cmb_phongchieu;
        private Label lbl_phongve;
        private CheckedListBox clb_ghengoi;
        private Label lbl_ghengoi;
        private Button btn_datve;
        private Button btn_docfile;
        private Button btn_ghifile;
        private ProgressBar pgb_tientrinh;
    }
}