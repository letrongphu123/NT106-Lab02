﻿namespace lab2
{
    partial class bangdieuhuong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_tittle = new Label();
            btn_bai01 = new Button();
            btn_bai02 = new Button();
            btn_bai03 = new Button();
            btn_bai04 = new Button();
            btn_bai05 = new Button();
            btn_bai06 = new Button();
            btn_bai07 = new Button();
            SuspendLayout();
            // 
            // lbl_tittle
            // 
            lbl_tittle.AutoSize = true;
            lbl_tittle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_tittle.Location = new Point(350, 21);
            lbl_tittle.Name = "lbl_tittle";
            lbl_tittle.Size = new Size(99, 41);
            lbl_tittle.TabIndex = 2;
            lbl_tittle.Text = "LAB 2";
            // 
            // btn_bai01
            // 
            btn_bai01.BackColor = SystemColors.ActiveCaption;
            btn_bai01.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai01.Location = new Point(86, 72);
            btn_bai01.Name = "btn_bai01";
            btn_bai01.Size = new Size(203, 62);
            btn_bai01.TabIndex = 12;
            btn_bai01.Text = "Bài 01";
            btn_bai01.UseVisualStyleBackColor = false;
            btn_bai01.Click += btn_bai01_Click;
            // 
            // btn_bai02
            // 
            btn_bai02.BackColor = SystemColors.ActiveCaption;
            btn_bai02.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai02.Location = new Point(505, 72);
            btn_bai02.Name = "btn_bai02";
            btn_bai02.Size = new Size(203, 62);
            btn_bai02.TabIndex = 13;
            btn_bai02.Text = "Bài 02";
            btn_bai02.UseVisualStyleBackColor = false;
            btn_bai02.Click += btn_bai02_Click;
            // 
            // btn_bai03
            // 
            btn_bai03.BackColor = SystemColors.ActiveCaption;
            btn_bai03.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai03.Location = new Point(86, 171);
            btn_bai03.Name = "btn_bai03";
            btn_bai03.Size = new Size(203, 62);
            btn_bai03.TabIndex = 14;
            btn_bai03.Text = "Bài 03";
            btn_bai03.UseVisualStyleBackColor = false;
            btn_bai03.Click += btn_bai03_Click;
            // 
            // btn_bai04
            // 
            btn_bai04.BackColor = SystemColors.ActiveCaption;
            btn_bai04.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai04.Location = new Point(505, 171);
            btn_bai04.Name = "btn_bai04";
            btn_bai04.Size = new Size(203, 62);
            btn_bai04.TabIndex = 15;
            btn_bai04.Text = "Bài 04";
            btn_bai04.UseVisualStyleBackColor = false;
            btn_bai04.Click += btn_bai04_Click;
            // 
            // btn_bai05
            // 
            btn_bai05.BackColor = SystemColors.ActiveCaption;
            btn_bai05.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai05.Location = new Point(86, 268);
            btn_bai05.Name = "btn_bai05";
            btn_bai05.Size = new Size(203, 62);
            btn_bai05.TabIndex = 16;
            btn_bai05.Text = "Bài 05";
            btn_bai05.UseVisualStyleBackColor = false;
            btn_bai05.Click += btn_bai05_Click;
            // 
            // btn_bai06
            // 
            btn_bai06.BackColor = SystemColors.ActiveCaption;
            btn_bai06.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai06.Location = new Point(505, 268);
            btn_bai06.Name = "btn_bai06";
            btn_bai06.Size = new Size(203, 62);
            btn_bai06.TabIndex = 17;
            btn_bai06.Text = "Bài 06";
            btn_bai06.UseVisualStyleBackColor = false;
            btn_bai06.Click += btn_bai06_Click;
            // 
            // btn_bai07
            // 
            btn_bai07.BackColor = SystemColors.ActiveCaption;
            btn_bai07.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_bai07.Location = new Point(86, 366);
            btn_bai07.Name = "btn_bai07";
            btn_bai07.Size = new Size(203, 62);
            btn_bai07.TabIndex = 18;
            btn_bai07.Text = "Bài 07";
            btn_bai07.UseVisualStyleBackColor = false;
            btn_bai07.Click += btn_bai07_Click;
            // 
            // bangdieuhuong
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_bai07);
            Controls.Add(btn_bai06);
            Controls.Add(btn_bai05);
            Controls.Add(btn_bai04);
            Controls.Add(btn_bai03);
            Controls.Add(btn_bai02);
            Controls.Add(btn_bai01);
            Controls.Add(lbl_tittle);
            Name = "bangdieuhuong";
            Text = "Bảng điều hướng";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_tittle;
        private Button btn_bai01;
        private Button btn_bai02;
        private Button btn_bai03;
        private Button btn_bai04;
        private Button btn_bai05;
        private Button btn_bai06;
        private Button btn_bai07;
    }
}